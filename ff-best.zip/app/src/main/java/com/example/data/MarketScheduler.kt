package com.example.data

import java.util.Calendar

data class BajiCurrentState(
    val bajiNumber: Int,
    val title: String,
    val isOpen: Boolean,
    val isPast: Boolean,
    val isUpcoming: Boolean,
    val remainingSeconds: Long,
    val timeLabel: String
)

object MarketScheduler {

    val defaultKolkataFatafatSchedules = listOf(
        BajiSchedule(1, "1st Baji", "08:00 AM", "09:50 AM", DateUtils.timeToMinutes("08:00 AM"), DateUtils.timeToMinutes("09:50 AM")),
        BajiSchedule(2, "2nd Baji", "09:55 AM", "11:30 AM", DateUtils.timeToMinutes("09:55 AM"), DateUtils.timeToMinutes("11:30 AM")),
        BajiSchedule(3, "3rd Baji", "11:55 AM", "12:50 PM", DateUtils.timeToMinutes("11:55 AM"), DateUtils.timeToMinutes("12:50 PM")),
        BajiSchedule(4, "4th Baji", "12:55 PM", "02:30 PM", DateUtils.timeToMinutes("12:55 PM"), DateUtils.timeToMinutes("02:30 PM")),
        BajiSchedule(5, "5th Baji", "02:35 PM", "03:55 PM", DateUtils.timeToMinutes("02:35 PM"), DateUtils.timeToMinutes("03:55 PM")),
        BajiSchedule(6, "6th Baji", "04:00 PM", "05:35 PM", DateUtils.timeToMinutes("04:00 PM"), DateUtils.timeToMinutes("05:35 PM")),
        BajiSchedule(7, "7th Baji", "05:40 PM", "06:55 PM", DateUtils.timeToMinutes("05:40 PM"), DateUtils.timeToMinutes("06:55 PM")),
        BajiSchedule(8, "8th Baji", "07:00 PM", "08:35 PM", DateUtils.timeToMinutes("07:00 PM"), DateUtils.timeToMinutes("08:35 PM"))
    )

    val defaultMainBazarSchedules = listOf(
        BajiSchedule(1, "Open Bet", "05:00 PM", "09:35 PM", DateUtils.timeToMinutes("05:00 PM"), DateUtils.timeToMinutes("09:35 PM")),
        BajiSchedule(2, "Close Bet", "09:40 PM", "11:35 PM", DateUtils.timeToMinutes("09:40 PM"), DateUtils.timeToMinutes("11:35 PM"))
    )

    fun getCurrentMinuteOfDay(): Int {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    }

    fun getCurrentSecondOfMinute(): Int {
        return Calendar.getInstance().get(Calendar.SECOND)
    }

    /**
     * Determines whether the given schedule is currently open for betting,
     * calculate remaining time in seconds.
     */
    fun evaluateBaji(schedule: BajiSchedule): BajiCurrentState {
        val currentMinutes = getCurrentMinuteOfDay()
        val currentSeconds = getCurrentSecondOfMinute()

        val isUpcoming = currentMinutes < schedule.startMinutes
        val isPast = currentMinutes >= schedule.endMinutes
        val isOpen = currentMinutes in schedule.startMinutes until schedule.endMinutes && schedule.isEnabled

        val remainingSeconds = if (isOpen) {
            val totalSeconds = (schedule.endMinutes - currentMinutes) * 60L - currentSeconds
            maxOf(0L, totalSeconds)
        } else 0L

        val timeLabel = "${schedule.startTime} - ${schedule.endTime}"

        return BajiCurrentState(
            bajiNumber = schedule.bajiNumber,
            title = schedule.title,
            isOpen = isOpen,
            isPast = isPast,
            isUpcoming = isUpcoming,
            remainingSeconds = remainingSeconds,
            timeLabel = timeLabel
        )
    }

    /**
     * Auto-selects active or next upcoming baji according to Kolkata Fatafat sequence:
     * 1baji closes -> 2baji auto select, ..., 8baji closes -> market closed.
     */
    fun getAutoSelectedBaji(schedules: List<BajiSchedule>): BajiSchedule {
        val currentMinutes = getCurrentMinuteOfDay()
        // 1. Look for currently open schedule
        for (sched in schedules) {
            if (currentMinutes in sched.startMinutes until sched.endMinutes && sched.isEnabled) {
                return sched
            }
        }
        // 2. Otherwise look for next upcoming schedule
        for (sched in schedules) {
            if (currentMinutes < sched.startMinutes && sched.isEnabled) {
                return sched
            }
        }
        // 3. If all past or default, return first or last
        return schedules.firstOrNull() ?: BajiSchedule(1, "1st Baji", "08:00 AM", "09:50 AM", 480, 590)
    }

    fun formatSecondsToTime(seconds: Long): String {
        val hrs = seconds / 3600
        val mins = (seconds % 3600) / 60
        val secs = seconds % 60
        return if (hrs > 0) {
            String.format("%02d:%02d:%02d", hrs, mins, secs)
        } else {
            String.format("%02d:%02d", mins, secs)
        }
    }
}
