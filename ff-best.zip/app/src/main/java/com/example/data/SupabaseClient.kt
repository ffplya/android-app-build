package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SupabaseClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun testConnection(url: String, key: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = url.trim().removeSuffix("/")
            val request = Request.Builder()
                .url("$cleanUrl/rest/v1/")
                .header("apikey", key.trim())
                .header("Authorization", "Bearer ${key.trim()}")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful || response.code == 404 || response.code == 200) {
                    Result.success("Connection successful! Supabase API is reachable.")
                } else {
                    Result.failure(Exception("Supabase responded with code: ${response.code} ${response.message}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getTableRows(url: String, key: String, table: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = url.trim().removeSuffix("/")
            val request = Request.Builder()
                .url("$cleanUrl/rest/v1/$table?select=*")
                .header("apikey", key.trim())
                .header("Authorization", "Bearer ${key.trim()}")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: "[]"
                if (response.isSuccessful) {
                    Result.success(body)
                } else {
                    Result.failure(Exception("Failed ($table): ${response.code} $body"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun insertRow(url: String, key: String, table: String, jsonObject: JSONObject): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = url.trim().removeSuffix("/")
            val requestBody = jsonObject.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url("$cleanUrl/rest/v1/$table")
                .header("apikey", key.trim())
                .header("Authorization", "Bearer ${key.trim()}")
                .header("Prefer", "return=representation")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    Result.success(body)
                } else {
                    Result.failure(Exception("Insert failed: ${response.code} $body"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateRow(url: String, key: String, table: String, filterColumn: String, filterValue: String, updateJson: JSONObject): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = url.trim().removeSuffix("/")
            val requestBody = updateJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url("$cleanUrl/rest/v1/$table?$filterColumn=eq.$filterValue")
                .header("apikey", key.trim())
                .header("Authorization", "Bearer ${key.trim()}")
                .header("Prefer", "return=representation")
                .patch(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    Result.success(body)
                } else {
                    Result.failure(Exception("Update failed: ${response.code} $body"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        fun getRecommendedSqlSchema(): String {
            return """
                -- FF BEST REALTIME SUPABASE TABLES --
                
                CREATE TABLE IF NOT EXISTS ff_users (
                    id TEXT PRIMARY KEY,
                    phone TEXT UNIQUE NOT NULL,
                    name TEXT NOT NULL,
                    password TEXT NOT NULL,
                    balance NUMERIC DEFAULT 0,
                    is_blocked BOOLEAN DEFAULT false,
                    created_at BIGINT
                );

                CREATE TABLE IF NOT EXISTS ff_bets (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    user_phone TEXT NOT NULL,
                    market_id TEXT NOT NULL,
                    market_name TEXT NOT NULL,
                    baji_number INT NOT NULL,
                    baji_title TEXT,
                    game_type TEXT NOT NULL,
                    selected_number TEXT NOT NULL,
                    amount NUMERIC NOT NULL,
                    potential_win NUMERIC NOT NULL,
                    status TEXT NOT NULL,
                    win_amount NUMERIC DEFAULT 0,
                    created_at BIGINT
                );

                CREATE TABLE IF NOT EXISTS ff_transactions (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    user_phone TEXT NOT NULL,
                    type TEXT NOT NULL,
                    amount NUMERIC NOT NULL,
                    status TEXT NOT NULL,
                    payment_method TEXT,
                    utr_number TEXT,
                    note TEXT,
                    created_at BIGINT
                );

                CREATE TABLE IF NOT EXISTS ff_results (
                    id TEXT PRIMARY KEY,
                    market_id TEXT NOT NULL,
                    market_name TEXT NOT NULL,
                    date_str TEXT NOT NULL,
                    baji_number INT NOT NULL,
                    baji_title TEXT,
                    single_digit TEXT,
                    patti_digits TEXT,
                    jodi_digits TEXT,
                    published_at BIGINT
                );

                CREATE TABLE IF NOT EXISTS ff_config (
                    id TEXT PRIMARY KEY,
                    admin_deposit_number TEXT,
                    admin_upi_id TEXT,
                    support_phone_1 TEXT,
                    support_phone_2 TEXT,
                    ticker_notice TEXT,
                    updated_at BIGINT
                );
            """.trimIndent()
        }
    }
}
