package com.example.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class GameType(val displayName: String, val multiplier: Float) {
    SINGLE("Single (0-9)", 9.5f),
    PATTI("3 Digit Patti", 140.0f),
    JODI("2 Digit Jodi", 95.0f)
}

enum class BetStatus {
    PENDING,
    WON,
    LOST
}

enum class TransactionType {
    DEPOSIT,
    WITHDRAWAL,
    BET_PLACED,
    BET_WON,
    ADMIN_CREDIT,
    ADMIN_DEBIT
}

enum class TransactionStatus {
    PENDING,
    APPROVED,
    REJECTED
}

data class User(
    val id: String = "",
    val phone: String = "",
    val name: String = "",
    val password: String = "",
    val balance: Double = 0.0,
    val isBlocked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class Bet(
    val id: String = "",
    val userId: String = "",
    val userPhone: String = "",
    val marketId: String = "",
    val marketName: String = "",
    val bajiNumber: Int = 1, // 1..8 for Kolkata Fatafat, 1 for Open / 2 for Close in Main Bazar
    val bajiTitle: String = "",
    val gameType: GameType = GameType.SINGLE,
    val selectedNumber: String = "",
    val amount: Double = 0.0,
    val potentialWin: Double = 0.0,
    val status: BetStatus = BetStatus.PENDING,
    val winAmount: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val resultPatti: String = "",
    val resultSingle: String = ""
)

data class Transaction(
    val id: String = "",
    val userId: String = "",
    val userPhone: String = "",
    val type: TransactionType = TransactionType.DEPOSIT,
    val amount: Double = 0.0,
    val status: TransactionStatus = TransactionStatus.PENDING,
    val paymentMethod: String = "UPI",
    val utrNumber: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class BajiSchedule(
    val bajiNumber: Int,
    val title: String,
    val startTime: String, // e.g. "08:00 AM"
    val endTime: String,   // e.g. "09:50 AM"
    val startMinutes: Int, // minutes from midnight
    val endMinutes: Int,
    val isEnabled: Boolean = true
)

data class Market(
    val id: String,
    val name: String,
    val bengaliName: String,
    val isKolkataFatafat: Boolean = true,
    val isEnabled: Boolean = true,
    val schedules: List<BajiSchedule> = emptyList()
)

data class MarketResult(
    val id: String = "",
    val marketId: String = "",
    val marketName: String = "",
    val dateStr: String = "", // e.g. "2026-09-23"
    val bajiNumber: Int = 1,
    val bajiTitle: String = "",
    val singleDigit: String = "", // 0-9
    val pattiDigits: String = "", // 3 digits e.g. "124"
    val jodiDigits: String = "",  // 2 digits e.g. "72"
    val publishedAt: Long = System.currentTimeMillis()
)

data class AppConfig(
    val adminDepositNumber: String = "9907182961",
    val adminUpiId: String = "9907182961@ybl",
    val supportPhone1: String = "9883881020",
    val supportPhone2: String = "78905 32818",
    val tickerNotice: String = "🔥 FF Best: Kolkata Fatafat & Main Bazar Live! 100% Trusted Real-time Payouts! WhatsApp Help: 9883881020 / 7890532818 🔥",
    val singleRate: Float = 9.5f,
    val pattiRate: Float = 140.0f,
    val jodiRate: Float = 95.0f,
    val minDeposit: Double = 100.0,
    val minWithdrawal: Double = 200.0,
    val supabaseUrl: String = "https://your-project.supabase.co",
    val supabaseAnonKey: String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    val isSupabaseEnabled: Boolean = false
)

data class LoginHistory(
    val id: String = "",
    val phone: String = "",
    val userName: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val ipAddress: String = "Mobile App"
)

typealias LoginLog = LoginHistory

object DateUtils {
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.US)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val displayFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US)

    fun getCurrentDateStr(): String = dateFormat.format(Date())
    fun formatDisplayDate(timestamp: Long): String = displayFormat.format(Date(timestamp))

    fun timeToMinutes(timeStr: String): Int {
        return try {
            val parts = timeStr.trim().split(" ", ":")
            var hour = parts[0].toInt()
            val min = parts[1].toInt()
            val amPm = parts[2].uppercase(Locale.US)
            if (amPm == "PM" && hour < 12) hour += 12
            if (amPm == "AM" && hour == 12) hour = 0
            hour * 60 + min
        } catch (e: Exception) {
            0
        }
    }
}
