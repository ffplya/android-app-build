package com.example.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object RealtimeRepository {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val supabaseClient = SupabaseClient()

    // Current logged in user (null if guest)
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // Is logged in as Admin
    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    // All Users
    private val _allUsers = MutableStateFlow<List<User>>(emptyList())
    val allUsers: StateFlow<List<User>> = _allUsers.asStateFlow()

    // Bets
    private val _allBets = MutableStateFlow<List<Bet>>(emptyList())
    val allBets: StateFlow<List<Bet>> = _allBets.asStateFlow()

    // Transactions
    private val _allTransactions = MutableStateFlow<List<Transaction>>(emptyList())
    val allTransactions: StateFlow<List<Transaction>> = _allTransactions.asStateFlow()

    // Results
    private val _allResults = MutableStateFlow<List<MarketResult>>(emptyList())
    val allResults: StateFlow<List<MarketResult>> = _allResults.asStateFlow()

    // Markets
    private val _markets = MutableStateFlow<List<Market>>(emptyList())
    val markets: StateFlow<List<Market>> = _markets.asStateFlow()

    // App Configuration / Settings
    private val _config = MutableStateFlow(AppConfig())
    val config: StateFlow<AppConfig> = _config.asStateFlow()

    // Login History
    private val _loginHistory = MutableStateFlow<List<LoginLog>>(emptyList())
    val loginHistory: StateFlow<List<LoginLog>> = _loginHistory.asStateFlow()

    // Network / Sync Status
    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncMessage = MutableStateFlow("Initialized")
    val lastSyncMessage: StateFlow<String> = _lastSyncMessage.asStateFlow()

    init {
        seedInitialData()
        startPeriodicSync()
    }

    private fun seedInitialData() {
        val initialMarkets = listOf(
            Market(
                id = "kolkata_fatafat",
                name = "KOLKATA FATAFAT",
                bengaliName = "কলকাতা ফটাফট",
                isKolkataFatafat = true,
                isEnabled = true,
                schedules = MarketScheduler.defaultKolkataFatafatSchedules
            ),
            Market(
                id = "main_bazar",
                name = "MAIN BAJAR",
                bengaliName = "মেন বাজার",
                isKolkataFatafat = false,
                isEnabled = true,
                schedules = MarketScheduler.defaultMainBazarSchedules
            )
        )
        _markets.value = initialMarkets

        // Preload sample results for today and yesterday so user sees a rich board immediately
        val today = DateUtils.getCurrentDateStr()
        val initialResults = listOf(
            MarketResult(
                id = UUID.randomUUID().toString(),
                marketId = "kolkata_fatafat",
                marketName = "KOLKATA FATAFAT",
                dateStr = today,
                bajiNumber = 1,
                bajiTitle = "1st Baji",
                singleDigit = "4",
                pattiDigits = "149",
                jodiDigits = "48",
                publishedAt = System.currentTimeMillis() - 7200000
            ),
            MarketResult(
                id = UUID.randomUUID().toString(),
                marketId = "kolkata_fatafat",
                marketName = "KOLKATA FATAFAT",
                dateStr = today,
                bajiNumber = 2,
                bajiTitle = "2nd Baji",
                singleDigit = "8",
                pattiDigits = "369",
                jodiDigits = "82",
                publishedAt = System.currentTimeMillis() - 3600000
            )
        )
        _allResults.value = initialResults

        // Add a demo user for quick testing if desired
        val demoUser = User(
            id = "user_demo",
            phone = "9876543210",
            name = "Demo Player",
            password = "123",
            balance = 500.0,
            isBlocked = false,
            createdAt = System.currentTimeMillis()
        )
        _allUsers.value = listOf(demoUser)
    }

    private fun startPeriodicSync() {
        scope.launch {
            while (true) {
                delay(15000) // check every 15s
                if (_config.value.isSupabaseEnabled && _config.value.supabaseUrl.startsWith("http")) {
                    syncFromSupabase()
                }
            }
        }
    }

    // --- Authentication ---

    fun login(phone: String, pass: String): Result<User> {
        val cleanPhone = phone.trim()
        val cleanPass = pass.trim()

        val found = _allUsers.value.find { it.phone == cleanPhone }
        return when {
            found == null -> Result.failure(Exception("Mobile number not registered"))
            found.password != cleanPass -> Result.failure(Exception("Incorrect password"))
            found.isBlocked -> Result.failure(Exception("Your account has been suspended by Admin"))
            else -> {
                _currentUser.value = found
                // log history
                val log = LoginLog(
                    id = UUID.randomUUID().toString(),
                    phone = found.phone,
                    userName = found.name,
                    timestamp = System.currentTimeMillis()
                )
                _loginHistory.update { listOf(log) + it }
                Result.success(found)
            }
        }
    }

    fun register(name: String, phone: String, pass: String): Result<User> {
        val cleanName = name.trim()
        val cleanPhone = phone.trim()
        val cleanPass = pass.trim()

        if (cleanPhone.length < 10) return Result.failure(Exception("Enter valid 10-digit mobile number"))
        if (cleanPass.length < 4) return Result.failure(Exception("Password must be at least 4 characters"))

        val existing = _allUsers.value.find { it.phone == cleanPhone }
        if (existing != null) return Result.failure(Exception("Mobile number already registered. Please login."))

        val newUser = User(
            id = UUID.randomUUID().toString(),
            phone = cleanPhone,
            name = cleanName.ifEmpty { "User ${cleanPhone.takeLast(4)}" },
            password = cleanPass,
            balance = 50.0, // Free welcome bonus ₹50!
            isBlocked = false,
            createdAt = System.currentTimeMillis()
        )

        _allUsers.update { it + newUser }
        _currentUser.value = newUser

        // Log transaction for welcome bonus
        val bonusTx = Transaction(
            id = UUID.randomUUID().toString(),
            userId = newUser.id,
            userPhone = newUser.phone,
            type = TransactionType.ADMIN_CREDIT,
            amount = 50.0,
            status = TransactionStatus.APPROVED,
            note = "Welcome Bonus",
            createdAt = System.currentTimeMillis()
        )
        _allTransactions.update { listOf(bonusTx) + it }

        // push to supabase in background
        scope.launch {
            pushUserToSupabase(newUser)
        }

        return Result.success(newUser)
    }

    fun forgotPasswordReset(phone: String, newPass: String): Result<String> {
        val cleanPhone = phone.trim()
        val user = _allUsers.value.find { it.phone == cleanPhone }
            ?: return Result.failure(Exception("Mobile number not found"))

        val updated = user.copy(password = newPass.trim())
        _allUsers.update { list -> list.map { if (it.id == updated.id) updated else it } }
        if (_currentUser.value?.id == updated.id) {
            _currentUser.value = updated
        }
        return Result.success("Password reset successfully. Please login.")
    }

    fun logout() {
        _currentUser.value = null
    }

    // --- Admin Auth ---

    fun loginAdmin(phone: String, pass: String): Boolean {
        if (phone.trim() == "9907182961" && pass.trim() == "9907182961") {
            _isAdminLoggedIn.value = true
            return true
        }
        return false
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
    }

    // --- Betting ---

    fun placeBet(
        marketId: String,
        marketName: String,
        bajiNumber: Int,
        bajiTitle: String,
        gameType: GameType,
        selectedNumber: String,
        amount: Double
    ): Result<Bet> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please login first"))

        if (user.balance < amount) {
            return Result.failure(Exception("Insufficient wallet balance. Please deposit ₹${amount - user.balance}"))
        }

        val multiplier = when (gameType) {
            GameType.SINGLE -> _config.value.singleRate
            GameType.PATTI -> _config.value.pattiRate
            GameType.JODI -> _config.value.jodiRate
        }
        val potentialWin = amount * multiplier

        val newBet = Bet(
            id = UUID.randomUUID().toString(),
            userId = user.id,
            userPhone = user.phone,
            marketId = marketId,
            marketName = marketName,
            bajiNumber = bajiNumber,
            bajiTitle = bajiTitle,
            gameType = gameType,
            selectedNumber = selectedNumber.trim(),
            amount = amount,
            potentialWin = potentialWin,
            status = BetStatus.PENDING,
            winAmount = 0.0,
            createdAt = System.currentTimeMillis()
        )

        // Deduct balance
        val updatedUser = user.copy(balance = user.balance - amount)
        _currentUser.value = updatedUser
        _allUsers.update { list -> list.map { if (it.id == user.id) updatedUser else it } }

        // Add bet
        _allBets.update { listOf(newBet) + it }

        // Add transaction
        val tx = Transaction(
            id = UUID.randomUUID().toString(),
            userId = user.id,
            userPhone = user.phone,
            type = TransactionType.BET_PLACED,
            amount = amount,
            status = TransactionStatus.APPROVED,
            note = "$marketName - $bajiTitle ($selectedNumber)",
            createdAt = System.currentTimeMillis()
        )
        _allTransactions.update { listOf(tx) + it }

        scope.launch {
            pushBetToSupabase(newBet)
            pushUserToSupabase(updatedUser)
        }

        return Result.success(newBet)
    }

    // --- Deposit & Withdrawal ---

    fun requestDeposit(amount: Double, paymentMethod: String, utrNumber: String): Result<Transaction> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please login first"))
        if (amount < _config.value.minDeposit) {
            return Result.failure(Exception("Minimum deposit amount is ₹${_config.value.minDeposit}"))
        }

        val tx = Transaction(
            id = UUID.randomUUID().toString(),
            userId = user.id,
            userPhone = user.phone,
            type = TransactionType.DEPOSIT,
            amount = amount,
            status = TransactionStatus.PENDING,
            paymentMethod = paymentMethod,
            utrNumber = utrNumber.trim(),
            note = "Deposit via $paymentMethod UTR: $utrNumber",
            createdAt = System.currentTimeMillis()
        )

        _allTransactions.update { listOf(tx) + it }
        scope.launch {
            pushTransactionToSupabase(tx)
        }

        return Result.success(tx)
    }

    fun requestWithdrawal(amount: Double, upiOrAccount: String): Result<Transaction> {
        val user = _currentUser.value ?: return Result.failure(Exception("Please login first"))
        if (amount < _config.value.minWithdrawal) {
            return Result.failure(Exception("Minimum withdrawal amount is ₹${_config.value.minWithdrawal}"))
        }
        if (user.balance < amount) {
            return Result.failure(Exception("Insufficient balance for withdrawal"))
        }

        // Deduct from user balance temporarily until approved or rejected
        val updatedUser = user.copy(balance = user.balance - amount)
        _currentUser.value = updatedUser
        _allUsers.update { list -> list.map { if (it.id == user.id) updatedUser else it } }

        val tx = Transaction(
            id = UUID.randomUUID().toString(),
            userId = user.id,
            userPhone = user.phone,
            type = TransactionType.WITHDRAWAL,
            amount = amount,
            status = TransactionStatus.PENDING,
            paymentMethod = "UPI/Bank",
            utrNumber = upiOrAccount,
            note = "Withdrawal request to $upiOrAccount",
            createdAt = System.currentTimeMillis()
        )

        _allTransactions.update { listOf(tx) + it }
        scope.launch {
            pushTransactionToSupabase(tx)
            pushUserToSupabase(updatedUser)
        }

        return Result.success(tx)
    }

    // --- Admin Controls ---

    fun approveDeposit(transactionId: String) {
        val tx = _allTransactions.value.find { it.id == transactionId } ?: return
        if (tx.status != TransactionStatus.PENDING) return

        val user = _allUsers.value.find { it.id == tx.userId } ?: return
        val updatedUser = user.copy(balance = user.balance + tx.amount)

        _allUsers.update { list -> list.map { if (it.id == user.id) updatedUser else it } }
        if (_currentUser.value?.id == user.id) {
            _currentUser.value = updatedUser
        }

        val updatedTx = tx.copy(status = TransactionStatus.APPROVED)
        _allTransactions.update { list -> list.map { if (it.id == tx.id) updatedTx else it } }

        scope.launch {
            pushTransactionToSupabase(updatedTx)
            pushUserToSupabase(updatedUser)
        }
    }

    fun rejectDeposit(transactionId: String) {
        val tx = _allTransactions.value.find { it.id == transactionId } ?: return
        val updatedTx = tx.copy(status = TransactionStatus.REJECTED)
        _allTransactions.update { list -> list.map { if (it.id == tx.id) updatedTx else it } }

        scope.launch {
            pushTransactionToSupabase(updatedTx)
        }
    }

    fun approveWithdrawal(transactionId: String) {
        val tx = _allTransactions.value.find { it.id == transactionId } ?: return
        if (tx.status != TransactionStatus.PENDING) return

        val updatedTx = tx.copy(status = TransactionStatus.APPROVED)
        _allTransactions.update { list -> list.map { if (it.id == tx.id) updatedTx else it } }

        scope.launch {
            pushTransactionToSupabase(updatedTx)
        }
    }

    fun rejectWithdrawal(transactionId: String) {
        val tx = _allTransactions.value.find { it.id == transactionId } ?: return
        if (tx.status != TransactionStatus.PENDING) return

        // Refund balance back to user
        val user = _allUsers.value.find { it.id == tx.userId }
        if (user != null) {
            val updatedUser = user.copy(balance = user.balance + tx.amount)
            _allUsers.update { list -> list.map { if (it.id == user.id) updatedUser else it } }
            if (_currentUser.value?.id == user.id) {
                _currentUser.value = updatedUser
            }
            scope.launch {
                pushUserToSupabase(updatedUser)
            }
        }

        val updatedTx = tx.copy(status = TransactionStatus.REJECTED)
        _allTransactions.update { list -> list.map { if (it.id == tx.id) updatedTx else it } }
        scope.launch {
            pushTransactionToSupabase(updatedTx)
        }
    }

    fun adminAdjustUserBalance(userId: String, amountDelta: Double, note: String) {
        val user = _allUsers.value.find { it.id == userId } ?: return
        val newBalance = maxOf(0.0, user.balance + amountDelta)
        val updatedUser = user.copy(balance = newBalance)

        _allUsers.update { list -> list.map { if (it.id == user.id) updatedUser else it } }
        if (_currentUser.value?.id == user.id) {
            _currentUser.value = updatedUser
        }

        val tx = Transaction(
            id = UUID.randomUUID().toString(),
            userId = user.id,
            userPhone = user.phone,
            type = if (amountDelta >= 0) TransactionType.ADMIN_CREDIT else TransactionType.ADMIN_DEBIT,
            amount = Math.abs(amountDelta),
            status = TransactionStatus.APPROVED,
            note = note.ifEmpty { "Admin Adjustment" },
            createdAt = System.currentTimeMillis()
        )
        _allTransactions.update { listOf(tx) + it }

        scope.launch {
            pushUserToSupabase(updatedUser)
            pushTransactionToSupabase(tx)
        }
    }

    fun adminResetUserPassword(userId: String, newPass: String) {
        val user = _allUsers.value.find { it.id == userId } ?: return
        val updatedUser = user.copy(password = newPass.trim())
        _allUsers.update { list -> list.map { if (it.id == user.id) updatedUser else it } }
        if (_currentUser.value?.id == user.id) {
            _currentUser.value = updatedUser
        }
        scope.launch {
            pushUserToSupabase(updatedUser)
        }
    }

    fun adminToggleUserBlock(userId: String) {
        val user = _allUsers.value.find { it.id == userId } ?: return
        val updatedUser = user.copy(isBlocked = !user.isBlocked)
        _allUsers.update { list -> list.map { if (it.id == user.id) updatedUser else it } }
        if (_currentUser.value?.id == user.id) {
            _currentUser.value = updatedUser
        }
        scope.launch {
            pushUserToSupabase(updatedUser)
        }
    }

    // --- Market & Timing Control ---

    fun toggleMarket(marketId: String, isEnabled: Boolean) {
        _markets.update { list ->
            list.map { if (it.id == marketId) it.copy(isEnabled = isEnabled) else it }
        }
    }

    fun toggleGlobalAllMarkets(enableAll: Boolean) {
        _markets.update { list ->
            list.map { it.copy(isEnabled = enableAll) }
        }
    }

    fun updateBajiTiming(marketId: String, bajiNumber: Int, startTime: String, endTime: String) {
        _markets.update { list ->
            list.map { market ->
                if (market.id == marketId) {
                    val updatedSchedules = market.schedules.map { sched ->
                        if (sched.bajiNumber == bajiNumber) {
                            sched.copy(
                                startTime = startTime,
                                endTime = endTime,
                                startMinutes = DateUtils.timeToMinutes(startTime),
                                endMinutes = DateUtils.timeToMinutes(endTime)
                            )
                        } else sched
                    }
                    market.copy(schedules = updatedSchedules)
                } else market
            }
        }
    }

    // --- Result Publishing with Automatic Win Credit ---

    /**
     * Publishes a result for a specific market & baji.
     * Automatically scans all pending bets matching market & baji,
     * checks for winning conditions, updates bet status, and CREDITS the winning user's wallet!
     */
    fun publishResult(
        marketId: String,
        marketName: String,
        bajiNumber: Int,
        bajiTitle: String,
        singleDigit: String,
        pattiDigits: String,
        jodiDigits: String
    ): Int {
        val today = DateUtils.getCurrentDateStr()
        val resultItem = MarketResult(
            id = UUID.randomUUID().toString(),
            marketId = marketId,
            marketName = marketName,
            dateStr = today,
            bajiNumber = bajiNumber,
            bajiTitle = bajiTitle,
            singleDigit = singleDigit.trim(),
            pattiDigits = pattiDigits.trim(),
            jodiDigits = jodiDigits.trim(),
            publishedAt = System.currentTimeMillis()
        )

        // Save result
        _allResults.update { listOf(resultItem) + it.filterNot { r -> r.marketId == marketId && r.dateStr == today && r.bajiNumber == bajiNumber } }

        // Process all pending bets for this market & baji
        var winCount = 0
        val betsToUpdate = _allBets.value.toMutableList()
        val userBalances = mutableMapOf<String, Double>()

        for (i in betsToUpdate.indices) {
            val bet = betsToUpdate[i]
            if (bet.marketId == marketId && bet.bajiNumber == bajiNumber && bet.status == BetStatus.PENDING) {
                val isWin = when (bet.gameType) {
                    GameType.SINGLE -> bet.selectedNumber == singleDigit.trim()
                    GameType.PATTI -> bet.selectedNumber == pattiDigits.trim()
                    GameType.JODI -> bet.selectedNumber == jodiDigits.trim()
                }

                if (isWin) {
                    val winAmount = bet.potentialWin
                    val wonBet = bet.copy(
                        status = BetStatus.WON,
                        winAmount = winAmount,
                        resultPatti = pattiDigits,
                        resultSingle = singleDigit
                    )
                    betsToUpdate[i] = wonBet
                    winCount++

                    // Accumulate balance credit for this user
                    userBalances[bet.userId] = (userBalances[bet.userId] ?: 0.0) + winAmount

                    // Add win transaction
                    val winTx = Transaction(
                        id = UUID.randomUUID().toString(),
                        userId = bet.userId,
                        userPhone = bet.userPhone,
                        type = TransactionType.BET_WON,
                        amount = winAmount,
                        status = TransactionStatus.APPROVED,
                        note = "WIN: $marketName - $bajiTitle (${bet.gameType.displayName} ${bet.selectedNumber})",
                        createdAt = System.currentTimeMillis()
                    )
                    _allTransactions.update { listOf(winTx) + it }
                } else {
                    val lostBet = bet.copy(
                        status = BetStatus.LOST,
                        resultPatti = pattiDigits,
                        resultSingle = singleDigit
                    )
                    betsToUpdate[i] = lostBet
                }
            }
        }

        _allBets.value = betsToUpdate

        // Apply balances to users
        if (userBalances.isNotEmpty()) {
            _allUsers.update { users ->
                users.map { u ->
                    val extra = userBalances[u.id]
                    if (extra != null) {
                        u.copy(balance = u.balance + extra)
                    } else u
                }
            }
            // Update current user if affected
            _currentUser.value?.let { curr ->
                val extra = userBalances[curr.id]
                if (extra != null) {
                    _currentUser.value = curr.copy(balance = curr.balance + extra)
                }
            }
        }

        scope.launch {
            pushResultToSupabase(resultItem)
        }

        return winCount
    }

    // --- Settings Updates ---

    fun updateConfig(newConfig: AppConfig) {
        _config.value = newConfig
    }

    // --- Supabase Sync Methods ---

    suspend fun testSupabaseConnection(url: String, key: String): Result<String> {
        return supabaseClient.testConnection(url, key)
    }

    private suspend fun syncFromSupabase() {
        val cfg = _config.value
        if (!cfg.isSupabaseEnabled) return

        try {
            _isSyncing.value = true
            // Sync users
            val usersRes = supabaseClient.getTableRows(cfg.supabaseUrl, cfg.supabaseAnonKey, "ff_users")
            if (usersRes.isSuccess) {
                val array = JSONArray(usersRes.getOrNull())
                val fetched = mutableListOf<User>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    fetched.add(
                        User(
                            id = obj.optString("id"),
                            phone = obj.optString("phone"),
                            name = obj.optString("name"),
                            password = obj.optString("password"),
                            balance = obj.optDouble("balance", 0.0),
                            isBlocked = obj.optBoolean("is_blocked", false),
                            createdAt = obj.optLong("created_at", System.currentTimeMillis())
                        )
                    )
                }
                if (fetched.isNotEmpty()) {
                    _allUsers.value = fetched
                    // Refresh current user if matching
                    _currentUser.value?.let { curr ->
                        fetched.find { it.id == curr.id }?.let { _currentUser.value = it }
                    }
                }
            }

            // Sync bets
            val betsRes = supabaseClient.getTableRows(cfg.supabaseUrl, cfg.supabaseAnonKey, "ff_bets")
            if (betsRes.isSuccess) {
                val array = JSONArray(betsRes.getOrNull())
                val fetched = mutableListOf<Bet>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    fetched.add(
                        Bet(
                            id = obj.optString("id"),
                            userId = obj.optString("user_id"),
                            userPhone = obj.optString("user_phone"),
                            marketId = obj.optString("market_id"),
                            marketName = obj.optString("market_name"),
                            bajiNumber = obj.optInt("baji_number", 1),
                            bajiTitle = obj.optString("baji_title"),
                            gameType = try { GameType.valueOf(obj.optString("game_type", "SINGLE")) } catch (e: Exception) { GameType.SINGLE },
                            selectedNumber = obj.optString("selected_number"),
                            amount = obj.optDouble("amount", 0.0),
                            potentialWin = obj.optDouble("potential_win", 0.0),
                            status = try { BetStatus.valueOf(obj.optString("status", "PENDING")) } catch (e: Exception) { BetStatus.PENDING },
                            winAmount = obj.optDouble("win_amount", 0.0),
                            createdAt = obj.optLong("created_at", System.currentTimeMillis())
                        )
                    )
                }
                if (fetched.isNotEmpty()) {
                    _allBets.value = fetched
                }
            }

            _lastSyncMessage.value = "Synced with Supabase at ${DateUtils.getCurrentDateStr()}"
        } catch (e: Exception) {
            _lastSyncMessage.value = "Sync error: ${e.message}"
        } finally {
            _isSyncing.value = false
        }
    }

    private suspend fun pushUserToSupabase(user: User) {
        val cfg = _config.value
        if (!cfg.isSupabaseEnabled) return
        try {
            val json = JSONObject().apply {
                put("id", user.id)
                put("phone", user.phone)
                put("name", user.name)
                put("password", user.password)
                put("balance", user.balance)
                put("is_blocked", user.isBlocked)
                put("created_at", user.createdAt)
            }
            supabaseClient.insertRow(cfg.supabaseUrl, cfg.supabaseAnonKey, "ff_users", json)
        } catch (ignored: Exception) {}
    }

    private suspend fun pushBetToSupabase(bet: Bet) {
        val cfg = _config.value
        if (!cfg.isSupabaseEnabled) return
        try {
            val json = JSONObject().apply {
                put("id", bet.id)
                put("user_id", bet.userId)
                put("user_phone", bet.userPhone)
                put("market_id", bet.marketId)
                put("market_name", bet.marketName)
                put("baji_number", bet.bajiNumber)
                put("baji_title", bet.bajiTitle)
                put("game_type", bet.gameType.name)
                put("selected_number", bet.selectedNumber)
                put("amount", bet.amount)
                put("potential_win", bet.potentialWin)
                put("status", bet.status.name)
                put("win_amount", bet.winAmount)
                put("created_at", bet.createdAt)
            }
            supabaseClient.insertRow(cfg.supabaseUrl, cfg.supabaseAnonKey, "ff_bets", json)
        } catch (ignored: Exception) {}
    }

    private suspend fun pushTransactionToSupabase(tx: Transaction) {
        val cfg = _config.value
        if (!cfg.isSupabaseEnabled) return
        try {
            val json = JSONObject().apply {
                put("id", tx.id)
                put("user_id", tx.userId)
                put("user_phone", tx.userPhone)
                put("type", tx.type.name)
                put("amount", tx.amount)
                put("status", tx.status.name)
                put("payment_method", tx.paymentMethod)
                put("utr_number", tx.utrNumber)
                put("note", tx.note)
                put("created_at", tx.createdAt)
            }
            supabaseClient.insertRow(cfg.supabaseUrl, cfg.supabaseAnonKey, "ff_transactions", json)
        } catch (ignored: Exception) {}
    }

    private suspend fun pushResultToSupabase(res: MarketResult) {
        val cfg = _config.value
        if (!cfg.isSupabaseEnabled) return
        try {
            val json = JSONObject().apply {
                put("id", res.id)
                put("market_id", res.marketId)
                put("market_name", res.marketName)
                put("date_str", res.dateStr)
                put("baji_number", res.bajiNumber)
                put("baji_title", res.bajiTitle)
                put("single_digit", res.singleDigit)
                put("patti_digits", res.pattiDigits)
                put("jodi_digits", res.jodiDigits)
                put("published_at", res.publishedAt)
            }
            supabaseClient.insertRow(cfg.supabaseUrl, cfg.supabaseAnonKey, "ff_results", json)
        } catch (ignored: Exception) {}
    }
}
