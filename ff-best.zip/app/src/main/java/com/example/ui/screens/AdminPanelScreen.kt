package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppConfig
import com.example.data.Bet
import com.example.data.BetStatus
import com.example.data.DateUtils
import com.example.data.LoginLog
import com.example.data.RealtimeRepository
import com.example.data.SupabaseClient
import com.example.data.Transaction
import com.example.data.TransactionStatus
import com.example.data.TransactionType
import com.example.data.User
import com.example.ui.components.StatusBadge
import com.example.ui.components.TxStatusBadge
import com.example.ui.components.copyToClipboard
import com.example.ui.theme.BrightAmber
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonRedLight
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldYellow
import com.example.ui.theme.TextGold
import com.example.ui.theme.GoldYellowLight
import com.example.ui.theme.LossRed
import com.example.ui.theme.PendingOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WinGreen
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedSection by remember { mutableIntStateOf(0) }

    val allUsers by RealtimeRepository.allUsers.collectAsState()
    val allBets by RealtimeRepository.allBets.collectAsState()
    val allTransactions by RealtimeRepository.allTransactions.collectAsState()
    val markets by RealtimeRepository.markets.collectAsState()
    val config by RealtimeRepository.config.collectAsState()
    val loginLogs by RealtimeRepository.loginHistory.collectAsState()

    val tabs = listOf(
        "Overview & Reports",
        "Publish Result",
        "Deposits (${allTransactions.count { it.type == TransactionType.DEPOSIT && it.status == TransactionStatus.PENDING }})",
        "Withdrawals (${allTransactions.count { it.type == TransactionType.WITHDRAWAL && it.status == TransactionStatus.PENDING }})",
        "Users (${allUsers.size})",
        "All Bets",
        "Market Timing",
        "UPI & WhatsApp",
        "Supabase Cloud",
        "Login Logs"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("FF BEST ADMIN PANEL", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Admin ID: 9907182961 • Master Access", color = TextMuted, fontSize = 11.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldYellow)
                    }
                },
                actions = {
                    TextButton(onClick = {
                        RealtimeRepository.logoutAdmin()
                        onNavigateBack()
                    }) {
                        Text("Exit Admin", color = LossRed, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(padding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedSection,
                containerColor = DarkSurfaceElevated,
                contentColor = GoldYellow,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedSection]),
                        color = GoldYellow
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedSection == index,
                        onClick = { selectedSection = index },
                        text = {
                            Text(
                                text = title,
                                color = if (selectedSection == index) GoldYellow else TextWhite,
                                fontWeight = if (selectedSection == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                        }
                    )
                }
            }

            Box(modifier = Modifier.fillMaxSize()) {
                when (selectedSection) {
                    0 -> AdminOverviewSection(allUsers, allBets, allTransactions)
                    1 -> AdminPublishResultSection(markets = markets)
                    2 -> AdminDepositsSection(allTransactions.filter { it.type == TransactionType.DEPOSIT })
                    3 -> AdminWithdrawalsSection(allTransactions.filter { it.type == TransactionType.WITHDRAWAL })
                    4 -> AdminUsersSection(allUsers)
                    5 -> AdminBetsSection(allBets)
                    6 -> AdminMarketTimingSection(markets)
                    7 -> AdminPaymentSupportSection(config)
                    8 -> AdminSupabaseSection(config)
                    9 -> AdminLoginLogsSection(loginLogs)
                }
            }
        }
    }
}

// 1. Overview & Reports
@Composable
fun AdminOverviewSection(users: List<User>, bets: List<Bet>, transactions: List<Transaction>) {
    val totalBetAmount = remember(bets) { bets.sumOf { it.amount } }
    val totalWinPaid = remember(bets) { bets.filter { it.status == BetStatus.WON }.sumOf { it.winAmount } }
    val netProfit = totalBetAmount - totalWinPaid

    val approvedDeposits = remember(transactions) {
        transactions.filter { it.type == TransactionType.DEPOSIT && it.status == TransactionStatus.APPROVED }.sumOf { it.amount }
    }
    val approvedWithdrawals = remember(transactions) {
        transactions.filter { it.type == TransactionType.WITHDRAWAL && it.status == TransactionStatus.APPROVED }.sumOf { it.amount }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("BUSINESS OVERVIEW & REPORTS", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Total Users", "${users.size}", GoldYellowLight, Modifier.weight(1f))
            MetricCard("Total Bets", "${bets.size}", TextWhite, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Bet Volume", "₹${String.format("%.2f", totalBetAmount)}", BrightAmber, Modifier.weight(1f))
            MetricCard("Winnings Paid", "₹${String.format("%.2f", totalWinPaid)}", WinGreen, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Deposits (In)", "₹${String.format("%.2f", approvedDeposits)}", WinGreen, Modifier.weight(1f))
            MetricCard("Withdrawals (Out)", "₹${String.format("%.2f", approvedWithdrawals)}", LossRed, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow)
        ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("NET PLATFORM PROFIT / LOSS", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "₹${String.format("%.2f", netProfit)}",
                    color = if (netProfit >= 0) WinGreen else LossRed,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

@Composable
fun MetricCard(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(label, color = TextMuted, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = valueColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// 2. Result Publishing with Auto Win Credit
@Composable
fun AdminPublishResultSection(markets: List<com.example.data.Market>) {
    val context = LocalContext.current
    var selectedMarketId by remember { mutableStateOf(markets.firstOrNull()?.id ?: "kolkata_fatafat") }
    var selectedBajiNumber by remember { mutableIntStateOf(1) }
    var singleDigit by remember { mutableStateOf("") }
    var pattiDigits by remember { mutableStateOf("") }
    var jodiDigits by remember { mutableStateOf("") }
    var successMsg by remember { mutableStateOf<String?>(null) }

    val currentMarket = markets.find { it.id == selectedMarketId }
    val currentSchedule = currentMarket?.schedules?.find { it.bajiNumber == selectedBajiNumber }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("NUMBER / RESULT MANAGEMENT", color = GoldYellow, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Publishing a result automatically evaluates all bets and credits user balances in real time!", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Select Market:", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    markets.forEach { m ->
                        val isSelected = selectedMarketId == m.id
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, if (isSelected) GoldYellow else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedMarketId = m.id
                                    selectedBajiNumber = m.schedules.firstOrNull()?.bajiNumber ?: 1
                                },
                            color = if (isSelected) CrimsonRed else DarkSurfaceElevated
                        ) {
                            Text(
                                text = m.name,
                                color = if (isSelected) Color.White else TextWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 10.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Select Baji / Timing Slot:", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    currentMarket?.schedules?.forEach { sched ->
                        val isSelected = selectedBajiNumber == sched.bajiNumber
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, if (isSelected) GoldYellow else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable { selectedBajiNumber = sched.bajiNumber },
                            color = if (isSelected) CrimsonRed else DarkSurfaceElevated
                        ) {
                            Text(
                                text = sched.title,
                                color = if (isSelected) Color.White else GoldYellowLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = singleDigit,
                    onValueChange = { if (it.length <= 1 && it.all { c -> c.isDigit() }) singleDigit = it },
                    label = { Text("Single Winning Digit (0-9)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldYellow,
                        unfocusedBorderColor = CrimsonRedLight,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = pattiDigits,
                    onValueChange = { if (it.length <= 3 && it.all { c -> c.isDigit() }) pattiDigits = it },
                    label = { Text("3-Digit Patti Pana (e.g. 149)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldYellow,
                        unfocusedBorderColor = CrimsonRedLight,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = jodiDigits,
                    onValueChange = { if (it.length <= 2 && it.all { c -> c.isDigit() }) jodiDigits = it },
                    label = { Text("2-Digit Jodi (Optional / Main Bazar)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldYellow,
                        unfocusedBorderColor = CrimsonRedLight,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    )
                )

                successMsg?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = WinGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (singleDigit.isEmpty() && pattiDigits.isEmpty()) {
                            Toast.makeText(context, "Please enter at least Single digit or Patti", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val winCount = RealtimeRepository.publishResult(
                            marketId = selectedMarketId,
                            marketName = currentMarket?.name ?: "KOLKATA FATAFAT",
                            bajiNumber = selectedBajiNumber,
                            bajiTitle = currentSchedule?.title ?: "Baji",
                            singleDigit = singleDigit,
                            pattiDigits = pattiDigits,
                            jodiDigits = jodiDigits
                        )

                        successMsg = "Result Published! $winCount winning bet(s) automatically calculated and credited."
                        Toast.makeText(context, successMsg, Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Publish, contentDescription = null, tint = GoldYellow)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PUBLISH RESULT & CREDIT WINNERS", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 3. Deposit Approval / Rejection
@Composable
fun AdminDepositsSection(deposits: List<Transaction>) {
    val context = LocalContext.current
    val pending = deposits.filter { it.status == TransactionStatus.PENDING }

    if (deposits.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("No deposit transactions recorded.", color = TextMuted)
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("DEPOSIT APPROVAL REQUESTS (${pending.size} Pending)", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            items(deposits) { tx ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (tx.status == TransactionStatus.PENDING) GoldYellow else CrimsonRedLight.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("User Phone: ${tx.userPhone}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Amount: ₹${tx.amount}", color = WinGreen, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Method: ${tx.paymentMethod}", color = GoldYellowLight, fontSize = 12.sp)
                                Text("UTR: ${tx.utrNumber}", color = TextGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(DateUtils.formatDisplayDate(tx.createdAt), color = TextMuted, fontSize = 10.sp)
                            }
                            TxStatusBadge(status = tx.status)
                        }

                        if (tx.status == TransactionStatus.PENDING) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        RealtimeRepository.approveDeposit(tx.id)
                                        Toast.makeText(context, "Deposit Approved! User balance credited.", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = WinGreen)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve", color = Color.Black, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        RealtimeRepository.rejectDeposit(tx.id)
                                        Toast.makeText(context, "Deposit Rejected", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = LossRed)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reject", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. Withdrawal Approval / Rejection
@Composable
fun AdminWithdrawalsSection(withdrawals: List<Transaction>) {
    val context = LocalContext.current
    val pending = withdrawals.filter { it.status == TransactionStatus.PENDING }

    if (withdrawals.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("No withdrawal transactions recorded.", color = TextMuted)
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("WITHDRAWAL APPROVAL REQUESTS (${pending.size} Pending)", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            items(withdrawals) { tx ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (tx.status == TransactionStatus.PENDING) GoldYellow else CrimsonRedLight.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("User Phone: ${tx.userPhone}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Withdraw Amount: ₹${tx.amount}", color = LossRed, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Payout Destination: ${tx.utrNumber}", color = GoldYellowLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(DateUtils.formatDisplayDate(tx.createdAt), color = TextMuted, fontSize = 10.sp)
                            }
                            TxStatusBadge(status = tx.status)
                        }

                        if (tx.status == TransactionStatus.PENDING) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        RealtimeRepository.approveWithdrawal(tx.id)
                                        Toast.makeText(context, "Withdrawal Approved & Paid", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = WinGreen)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve Payout", color = Color.Black, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        RealtimeRepository.rejectWithdrawal(tx.id)
                                        Toast.makeText(context, "Withdrawal Rejected & Refunded to User", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = LossRed)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reject", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. User Management & Password Reset
@Composable
fun AdminUsersSection(users: List<User>) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var adjustDialogUser by remember { mutableStateOf<User?>(null) }
    var passwordDialogUser by remember { mutableStateOf<User?>(null) }

    val filtered = users.filter {
        it.phone.contains(searchQuery.trim()) || it.name.contains(searchQuery.trim(), ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("USER MANAGEMENT & PASSWORDS", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by Phone or Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldYellow,
                unfocusedBorderColor = CrimsonRedLight,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { user ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(user.name, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Phone: ${user.phone}", color = GoldYellowLight, fontSize = 12.sp)
                                Text("Password: ${user.password}", color = TextMuted, fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("₹${String.format("%.2f", user.balance)}", color = WinGreen, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text(if (user.isBlocked) "SUSPENDED" else "ACTIVE", color = if (user.isBlocked) LossRed else WinGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { adjustDialogUser = user },
                                modifier = Modifier.weight(1f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldYellow)
                            ) {
                                Text("± Balance", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = { passwordDialogUser = user },
                                modifier = Modifier.weight(1f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, TextWhite),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite)
                            ) {
                                Text("Change Pass", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    RealtimeRepository.adminToggleUserBlock(user.id)
                                    Toast.makeText(context, if (user.isBlocked) "User unblocked" else "User blocked", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (user.isBlocked) WinGreen else LossRed),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = if (user.isBlocked) WinGreen else LossRed)
                            ) {
                                Text(if (user.isBlocked) "Unblock" else "Block", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    adjustDialogUser?.let { user ->
        var deltaStr by remember { mutableStateOf("100") }
        var isCredit by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { adjustDialogUser = null },
            title = { Text("Adjust Balance: ${user.name}", color = GoldYellow) },
            text = {
                Column {
                    Text("Current Balance: ₹${user.balance}", color = TextWhite)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row {
                        Button(
                            onClick = { isCredit = true },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isCredit) WinGreen else DarkSurfaceElevated)
                        ) {
                            Text("+ Add Balance")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { isCredit = false },
                            colors = ButtonDefaults.buttonColors(containerColor = if (!isCredit) LossRed else DarkSurfaceElevated)
                        ) {
                            Text("- Deduct")
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = deltaStr,
                        onValueChange = { deltaStr = it },
                        label = { Text("Amount (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = deltaStr.toDoubleOrNull() ?: 0.0
                        val delta = if (isCredit) amt else -amt
                        RealtimeRepository.adminAdjustUserBalance(user.id, delta, "Admin Manual Adjustment")
                        adjustDialogUser = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("Save Adjustment")
                }
            },
            dismissButton = {
                TextButton(onClick = { adjustDialogUser = null }) { Text("Cancel", color = GoldYellow) }
            },
            containerColor = DarkCard
        )
    }

    passwordDialogUser?.let { user ->
        var newPass by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { passwordDialogUser = null },
            title = { Text("Reset User Password", color = GoldYellow) },
            text = {
                Column {
                    Text("User: ${user.phone} (${user.name})", color = TextWhite)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("New Password") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPass.isNotEmpty()) {
                            RealtimeRepository.adminResetUserPassword(user.id, newPass)
                            Toast.makeText(context, "Password updated", Toast.LENGTH_SHORT).show()
                            passwordDialogUser = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("Change Password")
                }
            },
            dismissButton = {
                TextButton(onClick = { passwordDialogUser = null }) { Text("Cancel", color = GoldYellow) }
            },
            containerColor = DarkCard
        )
    }
}

// 6. All Bets & Win History
@Composable
fun AdminBetsSection(bets: List<Bet>) {
    var statusFilter by remember { mutableStateOf<BetStatus?>(null) }
    val filtered = bets.filter { statusFilter == null || it.status == statusFilter }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("ALL BETS & WIN AUDIT (${bets.size})", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip("All", statusFilter == null, { statusFilter = null }, Modifier.weight(1f))
            FilterChip("Won", statusFilter == BetStatus.WON, { statusFilter = BetStatus.WON }, Modifier.weight(1f))
            FilterChip("Pending", statusFilter == BetStatus.PENDING, { statusFilter = BetStatus.PENDING }, Modifier.weight(1f))
            FilterChip("Lost", statusFilter == BetStatus.LOST, { statusFilter = BetStatus.LOST }, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { bet ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("User: ${bet.userPhone}", color = GoldYellowLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("${bet.marketName} • ${bet.bajiTitle}", color = TextWhite, fontSize = 12.sp)
                                Text("Type: ${bet.gameType.displayName} | Pick: ${bet.selectedNumber}", color = TextWhite, fontSize = 12.sp)
                                Text(DateUtils.formatDisplayDate(bet.createdAt), color = TextMuted, fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Bet: ₹${bet.amount}", color = TextWhite, fontSize = 13.sp)
                                if (bet.status == BetStatus.WON) {
                                    Text("Win: +₹${bet.winAmount}", color = WinGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                                StatusBadge(status = bet.status)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 7. Market & Timing Controls
@Composable
fun AdminMarketTimingSection(markets: List<com.example.data.Market>) {
    val context = LocalContext.current
    var editingSchedule by remember { mutableStateOf<Pair<String, com.example.data.BajiSchedule>?>(null) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ALL MARKETS ON / OFF CONTROL", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }

        items(markets) { market ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(market.name, color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(market.bengaliName, color = TextMuted, fontSize = 12.sp)
                        }

                        Switch(
                            checked = market.isEnabled,
                            onCheckedChange = { RealtimeRepository.toggleMarket(market.id, it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = GoldYellow, checkedTrackColor = CrimsonRed)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Timings & Automatic Close Schedule:", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

                    market.schedules.forEach { sched ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${sched.title}: ${sched.startTime} to ${sched.endTime}", color = GoldYellowLight, fontSize = 12.sp)
                            IconButton(
                                onClick = { editingSchedule = Pair(market.id, sched) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Time", tint = GoldYellow, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    editingSchedule?.let { (marketId, sched) ->
        var startStr by remember { mutableStateOf(sched.startTime) }
        var endStr by remember { mutableStateOf(sched.endTime) }

        AlertDialog(
            onDismissRequest = { editingSchedule = null },
            title = { Text("Edit Timing: ${sched.title}", color = GoldYellow) },
            text = {
                Column {
                    OutlinedTextField(
                        value = startStr,
                        onValueChange = { startStr = it },
                        label = { Text("Start Time (e.g. 08:00 AM)") },
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = endStr,
                        onValueChange = { endStr = it },
                        label = { Text("Close / Auto-Off Time (e.g. 09:50 AM)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        RealtimeRepository.updateBajiTiming(marketId, sched.bajiNumber, startStr.trim(), endStr.trim())
                        Toast.makeText(context, "Timing Updated", Toast.LENGTH_SHORT).show()
                        editingSchedule = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("Save Time")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingSchedule = null }) { Text("Cancel", color = GoldYellow) }
            },
            containerColor = DarkCard
        )
    }
}

// 8. Payment & Support Settings (UPI ID, WhatsApp, Marquee Text)
@Composable
fun AdminPaymentSupportSection(config: AppConfig) {
    val context = LocalContext.current
    var depositPhone by remember { mutableStateOf(config.adminDepositNumber) }
    var upiId by remember { mutableStateOf(config.adminUpiId) }
    var phone1 by remember { mutableStateOf(config.supportPhone1) }
    var phone2 by remember { mutableStateOf(config.supportPhone2) }
    var ticker by remember { mutableStateOf(config.tickerNotice) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("PAYMENT & HELPLINE SETTINGS", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = depositPhone,
            onValueChange = { depositPhone = it },
            label = { Text("Admin Deposit Mobile Number") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = upiId,
            onValueChange = { upiId = it },
            label = { Text("Admin Deposit UPI ID (e.g. 9907182961@upi)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = phone1,
            onValueChange = { phone1 = it },
            label = { Text("Customer WhatsApp Support Number 1") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = phone2,
            onValueChange = { phone2 = it },
            label = { Text("Customer WhatsApp Support Number 2") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = ticker,
            onValueChange = { ticker = it },
            label = { Text("Home Screen Ticker Announcement / Notice") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val updated = config.copy(
                    adminDepositNumber = depositPhone.trim(),
                    adminUpiId = upiId.trim(),
                    supportPhone1 = phone1.trim(),
                    supportPhone2 = phone2.trim(),
                    tickerNotice = ticker.trim()
                )
                RealtimeRepository.updateConfig(updated)
                Toast.makeText(context, "Settings Saved Successfully!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
        ) {
            Text("SAVE CONFIGURATION", fontWeight = FontWeight.Bold)
        }
    }
}

// 9. Supabase Settings & SQL Schema
@Composable
fun AdminSupabaseSection(config: AppConfig) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var supabaseUrl by remember { mutableStateOf(config.supabaseUrl) }
    var anonKey by remember { mutableStateOf(config.supabaseAnonKey) }
    var isEnabled by remember { mutableStateOf(config.isSupabaseEnabled) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var showSqlDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("SUPABASE REALTIME CLOUD INTEGRATION", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("All users and bets can synchronize directly with your Supabase PostgREST cloud database without local persistence.", color = TextMuted, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Enable Supabase Sync", color = TextWhite, fontWeight = FontWeight.SemiBold)
            Switch(
                checked = isEnabled,
                onCheckedChange = { isEnabled = it },
                colors = SwitchDefaults.colors(checkedThumbColor = GoldYellow, checkedTrackColor = CrimsonRed)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = supabaseUrl,
            onValueChange = { supabaseUrl = it },
            label = { Text("Supabase Project URL (e.g. https://xxx.supabase.co)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = anonKey,
            onValueChange = { anonKey = it },
            label = { Text("Supabase Anon Public API Key") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    scope.launch {
                        testResult = "Testing connection..."
                        val res = RealtimeRepository.testSupabaseConnection(supabaseUrl, anonKey)
                        testResult = if (res.isSuccess) {
                            "Success: Supabase is online and reachable!"
                        } else {
                            "Error: ${res.exceptionOrNull()?.message}"
                        }
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow)
            ) {
                Text("Test Connection", color = GoldYellow)
            }

            Button(
                onClick = { showSqlDialog = true },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, TextWhite)
            ) {
                Text("View SQL Schema", color = TextWhite)
            }
        }

        testResult?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = if (it.startsWith("Success")) WinGreen else LossRed, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val updated = config.copy(
                    supabaseUrl = supabaseUrl.trim(),
                    supabaseAnonKey = anonKey.trim(),
                    isSupabaseEnabled = isEnabled
                )
                RealtimeRepository.updateConfig(updated)
                Toast.makeText(context, "Supabase Settings Saved!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
        ) {
            Text("SAVE SUPABASE CONFIG", fontWeight = FontWeight.Bold)
        }
    }

    if (showSqlDialog) {
        val sqlScript = SupabaseClient.getRecommendedSqlSchema()
        AlertDialog(
            onDismissRequest = { showSqlDialog = false },
            title = { Text("Supabase SQL Schema Script", color = GoldYellow) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("Copy and run this in your Supabase SQL Editor:", color = TextMuted, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = Color.Black,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = sqlScript,
                            color = WinGreen,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        copyToClipboard(context, sqlScript, "SQL Schema")
                        showSqlDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("Copy SQL Script")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSqlDialog = false }) { Text("Close", color = GoldYellow) }
            },
            containerColor = DarkCard
        )
    }
}

// 10. Login Logs & Audit
@Composable
fun AdminLoginLogsSection(logs: List<com.example.data.LoginLog>) {
    if (logs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("No user logins logged yet.", color = TextMuted)
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(logs) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkCard)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(log.userName, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Mobile: ${log.phone}", color = GoldYellowLight, fontSize = 12.sp)
                            Text(log.ipAddress, color = TextMuted, fontSize = 10.sp)
                        }
                        Text(DateUtils.formatDisplayDate(log.timestamp), color = TextMuted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
