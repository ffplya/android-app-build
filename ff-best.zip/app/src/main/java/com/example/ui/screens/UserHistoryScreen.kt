package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Bet
import com.example.data.BetStatus
import com.example.data.DateUtils
import com.example.data.MarketResult
import com.example.data.RealtimeRepository
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonRedLight
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldYellow
import com.example.ui.theme.GoldYellowLight
import com.example.ui.theme.LossRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WinGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyBetsScreen(onNavigateBack: () -> Unit) {
    val currentUser by RealtimeRepository.currentUser.collectAsState()
    val allBets by RealtimeRepository.allBets.collectAsState()
    var filterStatus by remember { mutableStateOf<BetStatus?>(null) }

    val userBets = remember(allBets, currentUser, filterStatus) {
        allBets.filter { it.userId == currentUser?.id }
            .filter { filterStatus == null || it.status == filterStatus }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Bet / Beed History", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldYellow)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(padding)
        ) {
            // Filter Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(label = "All", isSelected = filterStatus == null, onClick = { filterStatus = null }, modifier = Modifier.weight(1f))
                FilterChip(label = "Won", isSelected = filterStatus == BetStatus.WON, onClick = { filterStatus = BetStatus.WON }, modifier = Modifier.weight(1f))
                FilterChip(label = "Pending", isSelected = filterStatus == BetStatus.PENDING, onClick = { filterStatus = BetStatus.PENDING }, modifier = Modifier.weight(1f))
                FilterChip(label = "Lost", isSelected = filterStatus == BetStatus.LOST, onClick = { filterStatus = BetStatus.LOST }, modifier = Modifier.weight(1f))
            }

            if (userBets.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No bets found in this filter.", color = TextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(userBets) { bet ->
                        BetHistoryItem(bet = bet)
                    }
                    item { Spacer(modifier = Modifier.height(16.dp)) }
                }
            }
        }
    }
}

@Composable
fun FilterChip(label: String, isSelected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) CrimsonRed else DarkSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GoldYellow else Color.Transparent),
        onClick = onClick
    ) {
        Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = if (isSelected) Color.White else TextWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun BetHistoryItem(bet: Bet) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "${bet.marketName} • ${bet.bajiTitle}",
                        color = GoldYellow,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${bet.gameType.displayName} | Number: ${bet.selectedNumber}",
                        color = TextWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                StatusBadge(status = bet.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Amount: ₹${bet.amount}",
                    color = TextMuted,
                    fontSize = 12.sp
                )
                Text(
                    text = if (bet.status == BetStatus.WON) "Won: +₹${String.format("%.2f", bet.winAmount)}" else "Potential: ₹${String.format("%.2f", bet.potentialWin)}",
                    color = if (bet.status == BetStatus.WON) WinGreen else TextMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = DateUtils.formatDisplayDate(bet.createdAt),
                color = TextMuted.copy(alpha = 0.7f),
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsHistoryScreen(onNavigateBack: () -> Unit) {
    val allResults by RealtimeRepository.allResults.collectAsState()
    var selectedMarketTab by remember { mutableIntStateOf(0) } // 0 = Kolkata Fatafat, 1 = Main Bazar

    val filteredResults = remember(allResults, selectedMarketTab) {
        if (selectedMarketTab == 0) {
            allResults.filter { it.marketId == "kolkata_fatafat" }
        } else {
            allResults.filter { it.marketId == "main_bazar" }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Results & Draw History", color = GoldYellow, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldYellow)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedMarketTab,
                containerColor = DarkSurfaceElevated,
                contentColor = GoldYellow,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedMarketTab]),
                        color = GoldYellow
                    )
                }
            ) {
                Tab(
                    selected = selectedMarketTab == 0,
                    onClick = { selectedMarketTab = 0 },
                    text = { Text("KOLKATA FATAFAT (1-8 Baji)", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedMarketTab == 1,
                    onClick = { selectedMarketTab = 1 },
                    text = { Text("MAIN BAJAR", fontWeight = FontWeight.Bold) }
                )
            }

            if (filteredResults.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No results published yet.", color = TextMuted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredResults) { res ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkCard),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "${res.bajiTitle} (${res.dateStr})",
                                        color = TextWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Published: ${DateUtils.formatDisplayDate(res.publishedAt)}",
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = DarkSurfaceElevated,
                                        shape = RoundedCornerShape(8.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = res.pattiDigits.ifEmpty { "---" },
                                                color = GoldYellowLight,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(text = " - ", color = TextMuted)
                                            Text(
                                                text = res.singleDigit.ifEmpty { "-" },
                                                color = CrimsonRedLight,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                            if (res.jodiDigits.isNotEmpty()) {
                                                Text(text = " - ", color = TextMuted)
                                                Text(
                                                    text = res.jodiDigits,
                                                    color = WinGreen,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
