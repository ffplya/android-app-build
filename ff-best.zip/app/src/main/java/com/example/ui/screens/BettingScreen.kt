package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Bet
import com.example.data.GameType
import com.example.data.MarketScheduler
import com.example.data.RealtimeRepository
import com.example.ui.components.WalletHeaderChip
import com.example.ui.theme.BrightAmber
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonRedDark
import com.example.ui.theme.CrimsonRedLight
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldYellow
import com.example.ui.theme.GoldYellowLight
import com.example.ui.theme.LossRed
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WinGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BettingScreen(
    marketId: String,
    initialBajiNumber: Int,
    onNavigateBack: () -> Unit,
    onNavigateToDeposit: () -> Unit,
    onNavigateToMyBets: () -> Unit
) {
    val context = LocalContext.current
    val currentUser by RealtimeRepository.currentUser.collectAsState()
    val markets by RealtimeRepository.markets.collectAsState()
    val config by RealtimeRepository.config.collectAsState()

    val market = markets.find { it.id == marketId } ?: markets.firstOrNull()
    var selectedBajiNumber by remember { mutableIntStateOf(initialBajiNumber) }
    var selectedGameType by remember { mutableStateOf(GameType.SINGLE) }

    var selectedNumber by remember { mutableStateOf("") }
    var betAmountStr by remember { mutableStateOf("10") }
    var showSuccessDialog by remember { mutableStateOf<Bet?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val currentSchedule = market?.schedules?.find { it.bajiNumber == selectedBajiNumber }
        ?: market?.schedules?.firstOrNull()

    val bajiState = remember(currentSchedule, System.currentTimeMillis()) {
        currentSchedule?.let { MarketScheduler.evaluateBaji(it) }
    }

    val multiplier = when (selectedGameType) {
        GameType.SINGLE -> config.singleRate
        GameType.PATTI -> config.pattiRate
        GameType.JODI -> config.jodiRate
    }

    val betAmount = betAmountStr.toDoubleOrNull() ?: 0.0
    val potentialWin = betAmount * multiplier

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = market?.name ?: "Market Betting",
                            color = GoldYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "${currentSchedule?.title ?: "Baji"} • Rate: 1:$multiplier",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldYellow)
                    }
                },
                actions = {
                    WalletHeaderChip(
                        balance = currentUser?.balance ?: 0.0,
                        onDepositClick = onNavigateToDeposit
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = GoldYellow
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Market Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "${market?.name} - ${currentSchedule?.title}",
                            color = TextWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${currentSchedule?.startTime} TO ${currentSchedule?.endTime}",
                            color = GoldYellowLight,
                            fontSize = 12.sp
                        )
                    }

                    Surface(
                        color = if (bajiState?.isOpen == true) WinGreen.copy(alpha = 0.2f) else LossRed.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (bajiState?.isOpen == true) "BET OPEN" else "BET CLOSED",
                            color = if (bajiState?.isOpen == true) WinGreen else LossRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Game Type Selector: Single (0-9) | Patti (3-Digit) | Jodi (2-Digit)
            TabRow(
                selectedTabIndex = selectedGameType.ordinal,
                containerColor = DarkSurfaceElevated,
                contentColor = GoldYellow,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedGameType.ordinal]),
                        color = GoldYellow
                    )
                }
            ) {
                GameType.values().forEach { type ->
                    Tab(
                        selected = selectedGameType == type,
                        onClick = {
                            selectedGameType = type
                            selectedNumber = ""
                        },
                        text = {
                            Text(
                                text = type.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (selectedGameType == type) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedGameType == type) GoldYellow else TextMuted
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Number Selection Section based on Game Type
            when (selectedGameType) {
                GameType.SINGLE -> {
                    Text(
                        text = "Select Single Number (0 to 9):",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(5),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items((0..9).toList()) { num ->
                            val isSelected = selectedNumber == num.toString()
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        1.dp,
                                        if (isSelected) GoldYellow else CrimsonRedLight.copy(alpha = 0.5f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedNumber = num.toString() },
                                color = if (isSelected) CrimsonRed else DarkSurfaceElevated
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = num.toString(),
                                        color = if (isSelected) Color.White else GoldYellowLight,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                GameType.PATTI -> {
                    Text(
                        text = "Enter 3-Digit Patti Number (e.g. 123, 149, 369):",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = selectedNumber,
                        onValueChange = {
                            if (it.length <= 3 && it.all { char -> char.isDigit() }) {
                                selectedNumber = it
                            }
                        },
                        label = { Text("3-Digit Patti (000 - 999)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldYellow,
                            unfocusedBorderColor = CrimsonRedLight,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Popular Patti shortcuts:",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("124", "137", "248", "369", "579").forEach { sample ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { selectedNumber = sample },
                                color = DarkSurfaceElevated
                            ) {
                                Text(
                                    text = sample,
                                    color = GoldYellowLight,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                GameType.JODI -> {
                    Text(
                        text = "Enter 2-Digit Jodi Number (00 to 99):",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = selectedNumber,
                        onValueChange = {
                            if (it.length <= 2 && it.all { char -> char.isDigit() }) {
                                selectedNumber = it
                            }
                        },
                        label = { Text("2-Digit Jodi (00 - 99)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldYellow,
                            unfocusedBorderColor = CrimsonRedLight,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Bet Amount Chips & Custom Input
            Text(
                text = "Select Bet Amount (₹):",
                color = TextWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(10, 20, 50, 100, 500).forEach { amt ->
                    val isSelected = betAmountStr == amt.toString()
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, if (isSelected) GoldYellow else CrimsonRedLight.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .clickable { betAmountStr = amt.toString() },
                        color = if (isSelected) CrimsonRed else DarkSurfaceElevated
                    ) {
                        Text(
                            text = "₹$amt",
                            color = if (isSelected) Color.White else GoldYellowLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = betAmountStr,
                onValueChange = { if (it.all { char -> char.isDigit() }) betAmountStr = it },
                label = { Text("Custom Bet Amount (₹)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldYellow,
                    unfocusedBorderColor = CrimsonRedLight,
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite
                )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Bet Summary & Potential Win calculation
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Selected Number:", color = TextMuted, fontSize = 13.sp)
                        Text(
                            selectedNumber.ifEmpty { "Not selected" },
                            color = GoldYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Bet Amount:", color = TextMuted, fontSize = 13.sp)
                        Text("₹$betAmount", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Winning Rate Multiplier:", color = TextMuted, fontSize = 13.sp)
                        Text("1:$multiplier", color = GoldYellowLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    androidx.compose.material3.HorizontalDivider(color = CrimsonRedLight.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Potential Win:", color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "₹${String.format("%.2f", potentialWin)}",
                            color = WinGreen,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            errorMessage?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = it, color = LossRed, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Submit Bet Button
            Button(
                onClick = {
                    if (selectedNumber.isEmpty()) {
                        errorMessage = "Please choose or enter a valid number"
                        return@Button
                    }
                    if (selectedGameType == GameType.PATTI && selectedNumber.length != 3) {
                        errorMessage = "Patti requires exactly 3 digits"
                        return@Button
                    }
                    if (selectedGameType == GameType.JODI && selectedNumber.length != 2) {
                        errorMessage = "Jodi requires exactly 2 digits"
                        return@Button
                    }
                    if (betAmount <= 0) {
                        errorMessage = "Enter valid bet amount"
                        return@Button
                    }

                    val res = RealtimeRepository.placeBet(
                        marketId = market?.id ?: "kolkata_fatafat",
                        marketName = market?.name ?: "KOLKATA FATAFAT",
                        bajiNumber = selectedBajiNumber,
                        bajiTitle = currentSchedule?.title ?: "Baji",
                        gameType = selectedGameType,
                        selectedNumber = selectedNumber,
                        amount = betAmount
                    )

                    if (res.isSuccess) {
                        showSuccessDialog = res.getOrNull()
                        errorMessage = null
                    } else {
                        errorMessage = res.exceptionOrNull()?.message
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CrimsonRed,
                    contentColor = TextWhite
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "CONFIRM & PLACE BET (₹$betAmount)",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp
                )
            }
        }
    }

    // Success Receipt Dialog
    showSuccessDialog?.let { bet ->
        AlertDialog(
            onDismissRequest = { showSuccessDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = WinGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Bet Placed Successfully!", color = GoldYellow, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text("Market: ${bet.marketName}", color = TextWhite)
                    Text("Slot: ${bet.bajiTitle}", color = TextWhite)
                    Text("Game Type: ${bet.gameType.displayName}", color = TextWhite)
                    Text("Selected Number: ${bet.selectedNumber}", color = GoldYellowLight, fontWeight = FontWeight.Bold)
                    Text("Bet Amount: ₹${bet.amount}", color = TextWhite)
                    Text("Potential Win: ₹${String.format("%.2f", bet.potentialWin)}", color = WinGreen, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Good luck! Winning amount will be automatically credited to your wallet upon result announcement.", color = TextMuted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = null
                        onNavigateToMyBets()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("View My Bets")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSuccessDialog = null }) {
                    Text("Continue Betting", color = GoldYellow)
                }
            },
            containerColor = DarkCard
        )
    }
}
