package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FFDarkColorScheme = darkColorScheme(
    primary = CrimsonRedLight,
    onPrimary = Color.White,
    primaryContainer = CrimsonRedDark,
    onPrimaryContainer = GoldYellowLight,
    secondary = GoldYellow,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF423400),
    onSecondaryContainer = GoldYellowLight,
    tertiary = BrightAmber,
    onTertiary = Color.Black,
    background = DarkBackground,
    onBackground = TextWhite,
    surface = DarkSurface,
    onSurface = TextWhite,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextMuted,
    outline = Color(0xFF6E4040)
)

private val FFLightColorScheme = lightColorScheme(
    primary = CrimsonRed,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFEBEE),
    onPrimaryContainer = CrimsonRedDark,
    secondary = GoldYellowDark,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFFFFF8E1),
    onSecondaryContainer = Color(0xFF4E342E),
    tertiary = BrightAmber,
    onTertiary = Color.White,
    background = Color(0xFFFCF9F9),
    onBackground = Color(0xFF212121),
    surface = Color.White,
    onSurface = Color(0xFF212121),
    surfaceVariant = Color(0xFFF5F0F0),
    onSurfaceVariant = Color(0xFF5D4037),
    outline = Color(0xFFE0C0C0)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to sleek dark casino/betting look
    dynamicColor: Boolean = false, // Keep signature Red & Gold palette
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) FFDarkColorScheme else FFLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
