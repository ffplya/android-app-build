package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FF Best Premium Red and Yellow / Gold Color Palette
val CrimsonRed = Color(0xFFB71C1C)
val CrimsonRedDark = Color(0xFF7F0000)
val CrimsonRedLight = Color(0xFFD32F2F)

val GoldYellow = Color(0xFFFFD700)
val GoldYellowLight = Color(0xFFFFE082)
val GoldYellowDark = Color(0xFFFFB300)
val BrightAmber = Color(0xFFFF9800)

// Rich Dark Luxury Theme
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceElevated = Color(0xFF2C2424)
val DarkCard = Color(0xFF241616)

val TextGold = Color(0xFFFFE57F)
val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFB0BEC5)

// Status Colors
val WinGreen = Color(0xFF00E676)
val WinGreenDark = Color(0xFF00A152)
val LossRed = Color(0xFFFF1744)
val PendingOrange = Color(0xFFFF9100)
