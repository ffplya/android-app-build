package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.DateUtils
import com.example.data.RealtimeRepository
import com.example.data.Transaction
import com.example.data.TransactionType
import com.example.ui.components.TxStatusBadge
import com.example.ui.components.copyToClipboard
import com.example.ui.theme.BrightAmber
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.CrimsonRedLight
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldYellow
import com.example.ui.theme.GoldYellowLight
import com.example.ui.theme.LossRed
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WinGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(
    initialTab: Int = 0, // 0 = Deposit, 1 = Withdrawal, 2 = Transactions
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val currentUser by RealtimeRepository.currentUser.collectAsState()
    val config by RealtimeRepository.config.collectAsState()
    val allTransactions by RealtimeRepository.allTransactions.collectAsState()

    var selectedTab by remember { mutableIntStateOf(initialTab) }

    // User's own transactions
    val userTransactions = remember(allTransactions, currentUser) {
        allTransactions.filter { it.userId == currentUser?.id }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Wallet & Funds",
                        color = GoldYellow,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldYellow)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = GoldYellow
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(paddingValues)
        ) {
            // Balance Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("CURRENT WALLET BALANCE", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "₹${String.format("%.2f", currentUser?.balance ?: 0.0)}",
                        color = GoldYellow,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text("Instant 24x7 Deposit & Fast Withdrawal", color = TextWhite, fontSize = 11.sp)
                }
            }

            // Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurfaceElevated,
                contentColor = GoldYellow,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = GoldYellow
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Deposit Money", fontWeight = FontWeight.Bold, color = if (selectedTab == 0) GoldYellow else TextMuted) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Withdraw Money", fontWeight = FontWeight.Bold, color = if (selectedTab == 1) GoldYellow else TextMuted) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("History", fontWeight = FontWeight.Bold, color = if (selectedTab == 2) GoldYellow else TextMuted) }
                )
            }

            Box(modifier = Modifier.fillMaxSize()) {
                when (selectedTab) {
                    0 -> DepositSection(config = config, userPhone = currentUser?.phone ?: "", onDepositSubmitted = { selectedTab = 2 })
                    1 -> WithdrawalSection(balance = currentUser?.balance ?: 0.0, minWithdraw = config.minWithdrawal, userPhone = currentUser?.phone ?: "", onWithdrawSubmitted = { selectedTab = 2 })
                    2 -> TransactionHistorySection(transactions = userTransactions)
                }
            }
        }
    }
}

@Composable
fun DepositSection(
    config: com.example.data.AppConfig,
    userPhone: String,
    onDepositSubmitted: () -> Unit
) {
    val context = LocalContext.current
    var selectedAmount by remember { mutableStateOf("500") }
    var utrNumber by remember { mutableStateOf("") }
    var mobileNumber by remember { mutableStateOf(userPhone) }
    var selectedPaymentApp by remember { mutableStateOf("PhonePe") }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var showQrDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Admin Deposit Details Card with Copy Button
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Official Admin Deposit Number:",
                    color = TextWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = config.adminDepositNumber,
                        color = GoldYellow,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )

                    Button(
                        onClick = { copyToClipboard(context, config.adminDepositNumber, "Admin Number") },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("COPY NUMBER", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Admin UPI ID:", color = TextMuted, fontSize = 11.sp)
                        Text(config.adminUpiId, color = GoldYellowLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }

                    OutlinedButton(
                        onClick = { copyToClipboard(context, config.adminUpiId, "Admin UPI ID") },
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldYellow),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Copy UPI", fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Admin Deposit QR Code Card with Download / View
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.admin_upi_qr),
                        contentDescription = "Admin QR Code",
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, GoldYellow, RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Admin Payment QR Code", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("Scan using PhonePe / GPay / Paytm", color = TextMuted, fontSize = 11.sp)
                    }
                }

                Button(
                    onClick = { showQrDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldYellow),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("View QR", color = GoldYellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Amount Selector
        Text("Select Deposit Amount (₹):", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("100", "200", "500", "1000", "2000", "5000").forEach { amt ->
                val isSelected = selectedAmount == amt
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, if (isSelected) GoldYellow else CrimsonRedLight.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .clickable { selectedAmount = amt },
                    color = if (isSelected) CrimsonRed else DarkSurfaceElevated
                ) {
                    Text(
                        text = "₹$amt",
                        color = if (isSelected) Color.White else GoldYellowLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = selectedAmount,
            onValueChange = { if (it.all { c -> c.isDigit() }) selectedAmount = it },
            label = { Text("Custom Amount (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldYellow,
                unfocusedBorderColor = CrimsonRedLight,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            )
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Select Payment App
        Text("Select UPI Payment App:", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("PhonePe", "Google Pay", "Paytm", "Other UPI").forEach { app ->
                val isSelected = selectedPaymentApp == app
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, if (isSelected) GoldYellow else Color.Transparent, RoundedCornerShape(8.dp))
                        .clickable { selectedPaymentApp = app },
                    color = if (isSelected) CrimsonRed else DarkSurfaceElevated
                ) {
                    Text(
                        text = app,
                        color = if (isSelected) Color.White else TextWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Open UPI App direct button
        OutlinedButton(
            onClick = {
                try {
                    val amount = selectedAmount.toDoubleOrNull() ?: 100.0
                    val upiUri = Uri.parse("upi://pay?pa=${config.adminUpiId}&pn=FFBest&am=$amount&cu=INR")
                    val intent = Intent(Intent.ACTION_VIEW, upiUri)
                    context.startActivity(Intent.createChooser(intent, "Pay via $selectedPaymentApp"))
                } catch (e: Exception) {
                    Toast.makeText(context, "Could not launch UPI app: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            border = androidx.compose.foundation.BorderStroke(1.dp, WinGreen),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = WinGreen),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Pay ₹$selectedAmount directly via $selectedPaymentApp")
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Mobile Number & UTR Number input
        OutlinedTextField(
            value = mobileNumber,
            onValueChange = { mobileNumber = it },
            label = { Text("Sender Mobile Number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldYellow,
                unfocusedBorderColor = CrimsonRedLight,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = utrNumber,
            onValueChange = { utrNumber = it },
            label = { Text("12-Digit Transaction UTR / Ref ID") },
            placeholder = { Text("e.g. 423456789012") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldYellow,
                unfocusedBorderColor = CrimsonRedLight,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            )
        )

        errorMsg?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = LossRed, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val amt = selectedAmount.toDoubleOrNull() ?: 0.0
                if (amt < config.minDeposit) {
                    errorMsg = "Minimum deposit is ₹${config.minDeposit}"
                    return@Button
                }
                if (utrNumber.trim().length < 6) {
                    errorMsg = "Please enter valid 12-digit UTR / Ref Number from your UPI app receipt"
                    return@Button
                }

                val res = RealtimeRepository.requestDeposit(
                    amount = amt,
                    paymentMethod = selectedPaymentApp,
                    utrNumber = utrNumber.trim()
                )

                if (res.isSuccess) {
                    Toast.makeText(context, "Deposit request submitted! Admin will approve shortly.", Toast.LENGTH_LONG).show()
                    onDepositSubmitted()
                } else {
                    errorMsg = res.exceptionOrNull()?.message
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("SUBMIT DEPOSIT (₹$selectedAmount)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }

    if (showQrDialog) {
        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            title = {
                Text("Admin Deposit QR Code", color = GoldYellow, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.admin_upi_qr),
                        contentDescription = "Admin QR Code Full",
                        modifier = Modifier
                            .size(240.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(2.dp, GoldYellow, RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("UPI ID: ${config.adminUpiId}", color = TextWhite, fontWeight = FontWeight.SemiBold)
                    Text("Admin Number: ${config.adminDepositNumber}", color = GoldYellowLight, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Scan from PhonePe, Google Pay, or Paytm and copy 12-digit UTR number after payment.", color = TextMuted, fontSize = 11.sp, textAlign = TextAlign.Center)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        copyToClipboard(context, config.adminUpiId, "UPI ID")
                        showQrDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("Copy UPI & Close")
                }
            },
            containerColor = DarkCard
        )
    }
}

@Composable
fun WithdrawalSection(
    balance: Double,
    minWithdraw: Double,
    userPhone: String,
    onWithdrawSubmitted: () -> Unit
) {
    val context = LocalContext.current
    var amountStr by remember { mutableStateOf("200") }
    var mobileOrUpi by remember { mutableStateOf(userPhone) }
    var accountHolderName by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, WinGreen.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Withdrawable Balance", color = TextMuted, fontSize = 12.sp)
                Text(
                    text = "₹${String.format("%.2f", balance)}",
                    color = WinGreen,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Minimum withdrawal: ₹$minWithdraw • Transfer time: Instant / 15 mins",
                    color = TextWhite,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Select Amount to Withdraw:", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("200", "500", "1000", "2000").forEach { amt ->
                val isSelected = amountStr == amt
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, if (isSelected) GoldYellow else CrimsonRedLight.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .clickable { amountStr = amt },
                    color = if (isSelected) CrimsonRed else DarkSurfaceElevated
                ) {
                    Text(
                        text = "₹$amt",
                        color = if (isSelected) Color.White else GoldYellowLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = amountStr,
            onValueChange = { if (it.all { c -> c.isDigit() }) amountStr = it },
            label = { Text("Withdrawal Amount (₹)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldYellow,
                unfocusedBorderColor = CrimsonRedLight,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = mobileOrUpi,
            onValueChange = { mobileOrUpi = it },
            label = { Text("Transaction Mobile / UPI ID / PhonePe Number") },
            placeholder = { Text("e.g. 9876543210 or name@upi") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldYellow,
                unfocusedBorderColor = CrimsonRedLight,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = accountHolderName,
            onValueChange = { accountHolderName = it },
            label = { Text("Account Holder Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldYellow,
                unfocusedBorderColor = CrimsonRedLight,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            )
        )

        errorMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = LossRed, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val amt = amountStr.toDoubleOrNull() ?: 0.0
                if (amt < minWithdraw) {
                    errorMessage = "Minimum withdrawal is ₹$minWithdraw"
                    return@Button
                }
                if (amt > balance) {
                    errorMessage = "Insufficient balance for withdrawal"
                    return@Button
                }
                if (mobileOrUpi.trim().isEmpty()) {
                    errorMessage = "Please enter transaction mobile or UPI ID"
                    return@Button
                }

                val res = RealtimeRepository.requestWithdrawal(
                    amount = amt,
                    upiOrAccount = "${mobileOrUpi.trim()} (${accountHolderName.trim()})"
                )

                if (res.isSuccess) {
                    Toast.makeText(context, "Withdrawal request submitted! Payout processed shortly.", Toast.LENGTH_LONG).show()
                    onWithdrawSubmitted()
                } else {
                    errorMessage = res.exceptionOrNull()?.message
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("SUBMIT WITHDRAWAL (₹$amountStr)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
fun TransactionHistorySection(transactions: List<Transaction>) {
    if (transactions.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("No transactions found yet.", color = TextMuted, fontSize = 14.sp)
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(transactions) { tx ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRedLight.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = tx.type.name.replace("_", " "),
                                color = TextWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (tx.note.isNotEmpty()) {
                                Text(tx.note, color = GoldYellowLight, fontSize = 11.sp)
                            }
                            Text(
                                text = DateUtils.formatDisplayDate(tx.createdAt),
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "₹${String.format("%.2f", tx.amount)}",
                                color = when (tx.type) {
                                    TransactionType.DEPOSIT, TransactionType.BET_WON, TransactionType.ADMIN_CREDIT -> WinGreen
                                    else -> LossRed
                                },
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            TxStatusBadge(status = tx.status)
                        }
                    }
                }
            }
        }
    }
}
