package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.RealtimeRepository
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.BettingScreen
import com.example.ui.screens.ForgotPasswordScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MyBetsScreen
import com.example.ui.screens.RegisterScreen
import com.example.ui.screens.ResultsHistoryScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                FFBestApp()
            }
        }
    }
}

@Composable
fun FFBestApp() {
    val navController = rememberNavController()
    val currentUser by RealtimeRepository.currentUser.collectAsState()
    val isAdminLoggedIn by RealtimeRepository.isAdminLoggedIn.collectAsState()

    val startDestination = if (currentUser != null) "home" else "login"

    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = Modifier.fillMaxSize()
    ) {
        // Auth Routes
        composable("login") {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToRegister = { navController.navigate("register") },
                onNavigateToForgotPassword = { navController.navigate("forgot_password") },
                onNavigateToAdmin = { navController.navigate("admin_login") }
            )
        }

        composable("register") {
            RegisterScreen(
                onRegisterSuccess = {
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToLogin = { navController.popBackStack() }
            )
        }

        composable("forgot_password") {
            ForgotPasswordScreen(
                onResetSuccess = { navController.popBackStack() },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("admin_login") {
            AdminLoginScreen(
                onAdminLoginSuccess = {
                    navController.navigate("admin_panel") {
                        popUpTo("admin_login") { inclusive = true }
                    }
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Main Home Screen
        composable("home") {
            HomeScreen(
                onNavigateToBetting = { marketId, bajiNumber ->
                    navController.navigate("betting/$marketId/$bajiNumber")
                },
                onNavigateToDeposit = {
                    navController.navigate("wallet/0")
                },
                onNavigateToWithdrawal = {
                    navController.navigate("wallet/1")
                },
                onNavigateToMyBets = {
                    navController.navigate("my_bets")
                },
                onNavigateToResults = {
                    navController.navigate("results")
                },
                onNavigateToAdmin = {
                    if (isAdminLoggedIn) {
                        navController.navigate("admin_panel")
                    } else {
                        navController.navigate("admin_login")
                    }
                },
                onLogout = {
                    navController.navigate("login") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }

        // Betting Screen
        composable(
            route = "betting/{marketId}/{bajiNumber}",
            arguments = listOf(
                navArgument("marketId") { type = NavType.StringType },
                navArgument("bajiNumber") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val marketId = backStackEntry.arguments?.getString("marketId") ?: "kolkata_fatafat"
            val bajiNumber = backStackEntry.arguments?.getInt("bajiNumber") ?: 1

            BettingScreen(
                marketId = marketId,
                initialBajiNumber = bajiNumber,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToDeposit = { navController.navigate("wallet/0") },
                onNavigateToMyBets = { navController.navigate("my_bets") }
            )
        }

        // Wallet & Funds (Deposit, Withdrawal, History)
        composable(
            route = "wallet/{tab}",
            arguments = listOf(
                navArgument("tab") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val tab = backStackEntry.arguments?.getInt("tab") ?: 0
            WalletScreen(
                initialTab = tab,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // User Beed / Bet History
        composable("my_bets") {
            MyBetsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Results Board History
        composable("results") {
            ResultsHistoryScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Master Admin Panel
        composable("admin_panel") {
            AdminPanelScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
